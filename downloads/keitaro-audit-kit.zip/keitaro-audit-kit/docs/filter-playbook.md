# Keitaro traffic-filtering playbook

## Flow order
Keitaro checks Forced flows first, then Regular flows (top to bottom with split-testing off,
randomly by weight with it on), then the Default flow. With no Default flow, unmatched clicks get
Do Nothing.

1. **Forced: Bots.** Bot filter IS. Same landing page that people get, no offer attached,
   Collect clicks on. Ad-platform reviewers see the page people see; bot clicks never reach the
   affiliate network, and bot share stays measurable per source and placement.
2. **Regular flows**, each with its filters (country, device, schedule…). No regular flow without
   filters above the others.
3. **Default**: one fallback flow.

## What feeds the Bot filter
- Built-in lists: additional User-Agent list, Bot IP list, Spambot list; empty user agent as bot.
- Your own data: data-center prefixes and user-agent tokens from the analyzer, pasted into
  Settings → Bot lists. One IP or CIDR per line; large lists can be imported with
  `kctl run cli-php bots:import var/bots/bots.txt`.

## Network filters and what they need
| Filter | Needs | Without it |
|---|---|---|
| ISP, Connection type | Keitaro Geo or IP2Location DB4 | no ISP data to match |
| Proxy | IP2Location PX2 for IP-based detection | header-based only: misses proxies that don't announce themselves |
| IP | nothing | values separated by semicolons, CIDR, masks, intervals or /regex/; 65,534 characters max |

## How the analyzer decides
Bots (counted): declared crawlers, crawlers claiming Googlebot/Bingbot/etc. from addresses outside
the provider's published list, HTTP libraries and app HTTP stacks, headless browsers, empty or
unknown user agents, data-center networks with a browser user agent, Meta's network with a browser
user agent, the same IP and user agent clicking 6+ times in 10 minutes, clicks at machine-regular
intervals, and 10+ clicks from 4+ IPs of one subnet with one user agent in 10 minutes.

Suspicious (not counted): browser engines 40+ releases out of date, inconsistent user agents,
commercial VPN networks, 3 to 5 repeat clicks in 10 minutes, one IP with 8+ user agents in
10 minutes, Cloudflare edge addresses and private IPs (both point at a logging problem).

Kept human on purpose: iCloud Private Relay addresses. They sit on Akamai, Cloudflare and Fastly,
which are data-center networks, but the people behind them are ordinary Safari users.

## Limits
A click log can't separate bots that run real browsers on residential proxies from people. For
those, compare conversion quality per placement (approval rate, deposit rate, refunds) and block
placements that send clicks with no downstream value.

## Weekly routine
Export last week's clicks → run the analyzer → add new data-center prefixes to the bot list →
block placements over the bot-share threshold at the source → remove flood IPs older than a week →
compare bot share by source with the previous week.
