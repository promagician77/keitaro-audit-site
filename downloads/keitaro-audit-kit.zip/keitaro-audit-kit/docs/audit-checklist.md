# Keitaro audit checklist

What the audit covers, in the order I work through it. Items marked **(script)** are checked by
`audit/keitaro-audit.mjs` through the Admin API; the rest are checked by hand in the admin panel
or on the server, because the API doesn't expose them.

## 1. Installation and server
- Maintenance → Status: CPU stolen, disk space, ClickHouse upgrade notice. Keitaro's own advice for
  slow servers and 502s starts here.
- `kctl repair` on the server for common configuration problems; server configuration up to date.
- Maintenance → Logs → System and SSL: recurring errors, certificates stuck in "Requesting certificate".
- Admin access: one admin domain, IP allowlist, a separate API key per person or tool.

## 2. Domains and tracking setup
- **(script)** SSL on every tracking domain (D01), HTTPS-only on (D02).
- **(script)** Admin dashboard off on domains that appear in ad links (D03).
- **(script)** Crawlers set to Disallowed on tracking domains (D04).
- **(script)** Domain status OK (D05); index page campaign active (D06); Intercept 404 only with an
  index page (D07); idle parked domains listed (D08).
- Cloudflare or another proxy in front of the tracker: check the click log for proxy addresses. The
  analyzer reports the share of clicks from Cloudflare's own edge IPs; above 1% the tracker is
  logging the proxy instead of the visitor and GEO, ISP and bot checks see the wrong address.

## 3. Campaigns and flows
- **(script)** Every active campaign has a bot flow (F01), it is Forced (F03), and it sends no
  offers (F02).
- **(script)** No unfiltered regular flow above other regular flows (F04); one Default flow (F05, F06).
- **(script)** No OR across several IS NOT filters (F07); no filters with empty values (F08); IP
  and user-agent filters under the 65,534-character limit (F09).
- **(script)** Collect clicks on in offer flows (F10).
- **(script)** Split tests: binding on (F11), no active flow at weight 0 (F12).
- **(script)** Costs set or imported (F13); a traffic source attached so placements land in sub IDs (F14).
- **(script)** Every filter used exists on this tracker (F15), e.g. a custom filter file lost in a reinstall.
- **(script)** Flows don't point at disabled or deleted offers (F18).

## 4. Offers, affiliate networks and postbacks
- **(script)** Every offer passes `{subid}`, either in its URL or through the network's offer
  parameters (O01, O02). Keitaro calls subid the mandatory postback parameter.
- **(script)** CPA offers record revenue: fixed payout or payout from postback (O03).
- **(script)** https offer links (O04); unused and duplicate offers (O05, O06).
- Maintenance → Logs → Postbacks: "Incorrect subid", "Click for subid not found", duplicates.
- **(script, `--with-reports`)** Campaigns with heavy traffic and zero conversions in the last 7 days (R02).

## 5. Traffic filtering
- Settings → Bot lists: the built-in User-Agent list, Bot IP list and Spambot list on; empty user
  agent counted as bot; skip bot traffic in cost updates.
- **(script)** Custom bot list valid (B02), not covering consumer ISP ranges or /8-wide blocks (B03).
- Maintenance → Geo DBs: Keitaro Geo or IP2Location DB4 for the ISP filter; IP2Location PX2 for the
  Proxy filter. Without PX2 the Proxy filter only sees proxies that announce themselves in headers
  (F16, F17).
- Click log through the analyzer: bot share per source and placement, data-center networks, fake
  crawlers, floods, machine timing, subnet farms. Its outputs go into the bot list, the bot flow's
  IP and UserAgent filters, and the traffic source's blacklist.
- **(script, `--with-reports`)** Sources where Keitaro itself marks 20% or more of clicks as bots (R01).

## 6. Reporting
- Saved report: group by traffic source and sub ID (placement) with bots, bot share, proxies,
  conversions. Weekly re-run of the analyzer on the click export.

## Sources
- Flows: https://docs.keitaro.io/en/campaigns-and-streams/streams.html
- Filters: https://docs.keitaro.io/en/campaigns/filters.html
- Bot lists: https://docs.keitaro.io/en/settings/bot-lists.html
- Geo databases: https://docs.keitaro.io/en/settings/geo-databases.html
- Domains: https://docs.keitaro.io/en/maintenance/domains.html
- Affiliate networks: https://docs.keitaro.io/en/conversions-and-postback/adding-affiliate-networks.html
- Postback troubleshooting: https://docs.keitaro.io/en/conversions-and-postback/postback-troubleshooting.html
- Troubleshooting (server): https://docs.keitaro.io/en/maintenance/troubleshooting.html
- Admin API: https://docs.keitaro.io/en/development/admin-api.html
