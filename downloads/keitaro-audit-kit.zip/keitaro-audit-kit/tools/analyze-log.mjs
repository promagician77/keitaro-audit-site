#!/usr/bin/env node
// Offline click-log analysis, same engine as the web page.
//   node tools/analyze-log.mjs clicks.csv --out analysis-out
// Writes summary.json, bot-list.txt, ip-filter-N.txt, ua-filter.txt, ua-signatures.txt,
// flood-ips.txt, placements.csv and flagged-clicks.csv.
import fs from 'node:fs';
import path from 'node:path';
import { loadNetDBNode } from '../engine/netdb.mjs';
import { parseCSV, toCSV } from '../engine/csv.mjs';
import { autoMap, missingRequired, FIELDS } from '../engine/columns.mjs';
import { analyzeClicks, REASONS } from '../engine/analyze.mjs';
import { buildKeitaroOutputs } from '../engine/keitaro-out.mjs';

export async function main(argv = process.argv) {
  const file = argv[2];
  const outIdx = argv.indexOf('--out');
  const out = outIdx > 0 ? argv[outIdx + 1] : 'analysis-out';
  if (!file || file.startsWith('-')) { console.log('Usage: node tools/analyze-log.mjs clicks.csv [--out dir]'); return 0; }
  const table = parseCSV(fs.readFileSync(file, 'utf8'));
  const map = autoMap(table.headers);
  const missing = missingRequired(map);
  if (missing.length) {
    console.error(`Missing columns: ${missing.map((m) => FIELDS[m].label).join(', ')}. Headers found: ${table.headers.join(', ')}`);
    return 2;
  }
  const db = await loadNetDBNode();
  const t0 = Date.now();
  const res = analyzeClicks(table, map, db);
  const o = buildKeitaroOutputs(res);
  fs.mkdirSync(out, { recursive: true });
  const { hourly, ...summary } = res.summary;
  fs.writeFileSync(path.join(out, 'summary.json'), JSON.stringify({ file, mapping: map, ms: Date.now() - t0, ...summary }, null, 2));
  fs.writeFileSync(path.join(out, 'bot-list.txt'), o.botList.text + '\n');
  o.ipFilter.chunks.forEach((c, i) => fs.writeFileSync(path.join(out, `ip-filter-${i + 1}.txt`), c + '\n'));
  fs.writeFileSync(path.join(out, 'ua-filter.txt'), o.userAgent.regex + '\n');
  fs.writeFileSync(path.join(out, 'ua-signatures.txt'), o.userAgent.signatures + '\n');
  fs.writeFileSync(path.join(out, 'flood-ips.txt'), o.floodIps.list.map((x) => x.ip).join('\n') + '\n');
  fs.writeFileSync(path.join(out, 'placements.csv'), toCSV(['placement', 'clicks', 'bots', 'bot_share', 'main_reason'], o.placements.map((p) => [p.key, p.clicks, p.bot, p.botShare.toFixed(3), REASONS[p.topReason]?.label || ''])));
  const flagged = res.clicks.filter((c) => c.verdict !== 'human');
  fs.writeFileSync(path.join(out, 'flagged-clicks.csv'), toCSV([...table.headers, 'verdict', 'reasons', 'network'], flagged.map((c) => [...table.rows[c.i], c.verdict, c.reasons.join('|'), c.net && c.net.asn ? `AS${c.net.asn} ${c.net.name}` : ''])));
  const s = res.summary;
  console.log(`${s.total} clicks: ${s.bot} bots (${(s.botShare * 100).toFixed(1)}%), ${s.suspicious} suspicious, ${s.human} people → ${out}/`);
  return 0;
}

if (import.meta.url === `file://${process.argv[1]}`) main().then((c) => process.exit(c), (e) => { console.error(e.message); process.exit(1); });
