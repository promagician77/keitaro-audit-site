Keitaro audit kit (Node 20 or newer, no dependencies)

1) Read-only tracker audit
   KEITARO_API_KEY=your_key node audit/keitaro-audit.mjs --url https://your-tracker --out audit-out
   Sends GET requests only. Add --with-reports to also run two read-only report queries
   (POST /admin_api/v1/report/build) for 7 days of bot share per source and per campaign.
   Writes audit-out/audit.html, audit.md, findings.json, requests.log and a redacted snapshot.

   Prefer not to share a key? Make a redacted snapshot and send that file instead:
   KEITARO_API_KEY=your_key node audit/keitaro-audit.mjs --url https://your-tracker --snapshot-only --out audit-out

   Try it offline on the sample tracker:
   node audit/keitaro-audit.mjs --from-snapshot examples/sample-tracker-snapshot.json --out audit-out

2) Click-log analysis (same engine as the web page)
   node tools/analyze-log.mjs your-clicks.csv --out analysis-out
   Export from Keitaro: Reports → Clicks → Export CSV, with IP, User Agent, Datetime and, if you
   can, Traffic source, Flow, Sub ID (placement) and Is bot columns.
   Try it: node tools/analyze-log.mjs examples/sample-clicks.csv --out analysis-out

Network data: BGP origin ASNs (ip-location-db origin-asn, PDDL), data-center ASNs (X4BNet
lists_vpn, MIT), provider-published crawler, relay and CDN ranges (lord-alfred/ipranges, CC0).
isbot (Unlicense) is bundled in engine/vendor.
