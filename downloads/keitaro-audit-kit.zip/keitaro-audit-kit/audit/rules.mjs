// Audit rules for a Keitaro snapshot. Each rule cites the Keitaro documentation page that
// describes the behaviour it relies on. Rules only read the snapshot.
import { parseCIDR, parseIP, v4ToString } from '../engine/ip.mjs';

export const DOCS = {
  flows: 'https://docs.keitaro.io/en/campaigns-and-streams/streams.html',
  filters: 'https://docs.keitaro.io/en/campaigns/filters.html',
  campaign: 'https://docs.keitaro.io/en/campaigns-and-streams/creating-campaign.html',
  botlists: 'https://docs.keitaro.io/en/settings/bot-lists.html',
  domains: 'https://docs.keitaro.io/en/maintenance/domains.html',
  networks: 'https://docs.keitaro.io/en/conversions-and-postback/adding-affiliate-networks.html',
  postback: 'https://docs.keitaro.io/en/conversions-and-postback/postback.html',
  offers: 'https://docs.keitaro.io/en/networks/offers.html',
  geodb: 'https://docs.keitaro.io/en/settings/geo-databases.html',
  api: 'https://docs.keitaro.io/en/development/admin-api.html',
};

export const SEVERITY_ORDER = { high: 0, medium: 1, low: 2, info: 3 };

const VALUE_FILTERS = new Set(['country', 'region', 'city', 'ip', 'isp', 'connection_type', 'operator', 'mobile_operator', 'user_agent', 'useragent', 'browser', 'browser_version', 'os', 'os_version', 'device_type', 'device_model', 'language', 'referrer', 'keyword', 'search_engine', 'site', 'parameter', 'ad_campaign_id', 'creative_id', 'x_requested_with']);
const isValueFilter = (n) => VALUE_FILTERS.has(n) || /^sub_id_\d+$/.test(n);
const active = (x) => x && (x.state === undefined || x.state === null || x.state === 'active');
const fname = (f) => String(f.name || '').toLowerCase();

export function payloadList(p) {
  if (p === null || p === undefined) return [];
  if (Array.isArray(p)) return p.map((x) => (typeof x === 'object' ? JSON.stringify(x) : String(x))).map((s) => s.trim()).filter(Boolean);
  const s = String(p).trim();
  if (!s) return [];
  if (s.startsWith('[')) { try { return payloadList(JSON.parse(s)); } catch { /* fall through */ } }
  return s.split(/[;\n]/).map((x) => x.trim()).filter(Boolean);
}
const payloadChars = (p) => (Array.isArray(p) ? p.join(';') : String(p ?? '')).length;

const offerIds = (s) => (Array.isArray(s.offers) ? s.offers : []).map((o) => Number(o.offer_id ?? o.id)).filter((x) => Number.isFinite(x));
const isBotFlow = (s) => (s.filters || []).some((f) => fname(f) === 'bot' && (f.mode || 'accept') === 'accept');

function F(rule, entity, detail, extra = {}) {
  return { rule: rule.id, severity: extra.severity || rule.severity, area: rule.area, title: rule.title, entity, detail, fix: extra.fix || rule.fix, where: rule.where, source: rule.source };
}
const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
const camp = (c) => ({ type: 'campaign', id: c.id, name: c.name });
const flow = (c, s) => ({ type: 'flow', id: s.id, name: `${c.name} → ${s.name || '#' + s.id}` });

export const RULES = [
  // ---------- flows ----------
  {
    id: 'F01', severity: 'high', area: 'Flows', title: 'No bot flow in an active campaign',
    fix: 'Add a Forced flow at the top with the Bot filter set to IS. Send it to the same landing as people with no offer attached, and keep Collect clicks on so bot share stays measurable.',
    where: 'Campaign → Flows → Create flow (type Forced) → Filters → Bot', source: DOCS.filters,
    run: (s) => (s.campaigns || []).filter(active).flatMap((c) => {
      const flows = (s.streams[c.id] || []).filter(active);
      return flows.length && !flows.some(isBotFlow) ? [F(RULES_BY_ID.F01, camp(c), `${flows.length} active flows, none with the Bot filter. Bot clicks go through the same flows as people and reach offers.`)] : [];
    }),
  },
  {
    id: 'F02', severity: 'high', area: 'Flows', title: 'Bot flow sends bots to offers',
    fix: 'Remove the offers from the bot flow. Bot clicks that reach an affiliate network are counted as real clicks there and lower your EPC and approval rate.',
    where: 'Campaign → bot flow → Schema', source: DOCS.flows,
    run: (s) => (s.campaigns || []).filter(active).flatMap((c) => (s.streams[c.id] || []).filter((f) => active(f) && isBotFlow(f) && offerIds(f).length)
      .map((f) => F(RULES_BY_ID.F02, flow(c, f), `The bot flow has ${plural(offerIds(f).length, 'offer', 'offers')} attached (${offerIds(f).length === 1 ? 'id' : 'ids'} ${offerIds(f).join(', ')}).`))),
  },
  {
    id: 'F03', severity: 'medium', area: 'Flows', title: 'Bot flow is not Forced',
    fix: 'Change the bot flow type to Forced. Keitaro checks Forced flows before Regular ones, so bots are caught before any offer flow can take them.',
    where: 'Campaign → bot flow → Type', source: DOCS.flows,
    run: (s) => (s.campaigns || []).filter(active).flatMap((c) => {
      const flows = (s.streams[c.id] || []).filter(active);
      return flows.filter((f) => isBotFlow(f) && f.type !== 'forced').map((f) => {
        const before = flows.filter((x) => x.type === 'regular' && x !== f && !(x.filters || []).length && Number(x.position) < Number(f.position));
        const high = c.type === 'weight' || before.length > 0;
        const why = c.type === 'weight'
          ? 'The campaign splits regular flows by weight, so a random flow is tried first and an unfiltered offer flow can take the bot.'
          : before.length ? `Regular flow "${before[0].name}" has no filters and sits above it, so it takes the bots first.` : 'It only works while it stays first among regular flows.';
        return F(RULES_BY_ID.F03, flow(c, f), `The bot flow is a ${f.type} flow. ${why}`, { severity: high ? 'high' : 'medium' });
      });
    }),
  },
  {
    id: 'F04', severity: 'high', area: 'Flows', title: 'Flows that never receive traffic',
    fix: 'Move the unfiltered regular flow to the bottom, give it filters, or turn it into the Default flow.',
    where: 'Campaign → Flows (drag to reorder)', source: DOCS.flows,
    run: (s) => (s.campaigns || []).filter((c) => active(c) && c.type !== 'weight').flatMap((c) => {
      const regular = (s.streams[c.id] || []).filter((f) => active(f) && f.type === 'regular').sort((a, b) => Number(a.position) - Number(b.position));
      const i = regular.findIndex((f) => !(f.filters || []).length);
      if (i < 0 || i === regular.length - 1) return [];
      const dead = regular.slice(i + 1);
      return [F(RULES_BY_ID.F04, camp(c), `With split-testing off, Keitaro checks regular flows top to bottom. "${regular[i].name}" has no filters, so ${plural(dead.length, 'flow', 'flows')} below it ${dead.length === 1 ? 'gets' : 'get'} nothing: ${dead.map((d) => `"${d.name}"`).join(', ')}.`)];
    }),
  },
  {
    id: 'F05', severity: 'medium', area: 'Flows', title: 'No Default flow',
    fix: 'Add a Default flow. Without one, clicks that match no flow get the Do Nothing action and are lost.',
    where: 'Campaign → Flows → Create flow (type Default)', source: DOCS.flows,
    run: (s) => (s.campaigns || []).filter(active).flatMap((c) => {
      const flows = (s.streams[c.id] || []).filter(active);
      return flows.length && !flows.some((f) => f.type === 'default') ? [F(RULES_BY_ID.F05, camp(c), 'No active Default flow. Unmatched clicks are dropped.')] : [];
    }),
  },
  {
    id: 'F06', severity: 'low', area: 'Flows', title: 'More than one Default flow',
    fix: 'Keep one Default flow and archive the rest so it is clear where fallback traffic goes.',
    where: 'Campaign → Flows', source: DOCS.flows,
    run: (s) => (s.campaigns || []).filter(active).flatMap((c) => {
      const d = (s.streams[c.id] || []).filter((f) => active(f) && f.type === 'default');
      return d.length > 1 ? [F(RULES_BY_ID.F06, camp(c), `${d.length} active Default flows: ${d.map((x) => `"${x.name}"`).join(', ')}.`)] : [];
    }),
  },
  {
    id: 'F07', severity: 'medium', area: 'Filters', title: 'OR logic with several IS NOT filters',
    fix: 'Switch the flow to AND, or rewrite the conditions as IS. "Country IS NOT US OR country IS NOT CA" is true for every click.',
    where: 'Flow → Filters → AND/OR', source: DOCS.filters,
    run: (s) => (s.campaigns || []).filter(active).flatMap((c) => (s.streams[c.id] || []).filter((f) => active(f) && f.filter_or && (f.filters || []).filter((x) => x.mode === 'reject').length >= 2)
      .map((f) => F(RULES_BY_ID.F07, flow(c, f), `OR is on with ${(f.filters || []).filter((x) => x.mode === 'reject').length} IS NOT filters (${(f.filters || []).filter((x) => x.mode === 'reject').map(fname).join(', ')}). A click passes if any one of them is true, which is almost every click.`))),
  },
  {
    id: 'F08', severity: 'medium', area: 'Filters', title: 'Filter with no values',
    fix: 'Fill in the filter values or delete the filter.',
    where: 'Flow → Filters', source: DOCS.filters,
    run: (s) => (s.campaigns || []).filter(active).flatMap((c) => (s.streams[c.id] || []).filter(active).flatMap((f) => (f.filters || [])
      .filter((x) => isValueFilter(fname(x)) && payloadList(x.payload).length === 0)
      .map((x) => F(RULES_BY_ID.F08, flow(c, f), `The "${fname(x)}" filter (${x.mode === 'reject' ? 'IS NOT' : 'IS'}) has an empty value list.`)))),
  },
  {
    id: 'F09', severity: 'low', area: 'Filters', title: 'IP or user-agent filter close to the length limit',
    fix: 'Move long IP lists to Settings → Bot lists, or split them across filters. Keitaro caps these fields at 65,534 characters.',
    where: 'Flow → Filters → IP / UserAgent', source: DOCS.filters,
    run: (s) => (s.campaigns || []).filter(active).flatMap((c) => (s.streams[c.id] || []).filter(active).flatMap((f) => (f.filters || [])
      .filter((x) => ['ip', 'user_agent', 'useragent'].includes(fname(x)) && payloadChars(x.payload) > 60000)
      .map((x) => F(RULES_BY_ID.F09, flow(c, f), `The ${fname(x)} filter holds ${payloadChars(x.payload).toLocaleString('en-US')} characters (limit 65,534).`)))),
  },
  {
    id: 'F10', severity: 'medium', area: 'Reporting', title: 'Flow does not save clicks',
    fix: 'Turn Collect clicks on, unless this flow is meant to be invisible in reports.',
    where: 'Flow → Collect clicks', source: DOCS.flows,
    run: (s) => (s.campaigns || []).filter(active).flatMap((c) => (s.streams[c.id] || []).filter((f) => active(f) && f.collect_clicks === false && !isBotFlow(f))
      .map((f) => F(RULES_BY_ID.F10, flow(c, f), 'Collect clicks is off, so this flow\'s traffic is missing from statistics and cost/ROI reports.'))),
  },
  {
    id: 'F11', severity: 'low', area: 'Split tests', title: 'Split test without visitor binding',
    fix: 'Turn on Bind visitors so a returning visitor sees the same flow, landing and offer during the test.',
    where: 'Campaign → Settings → Bind visitors', source: DOCS.campaign,
    run: (s) => (s.campaigns || []).filter((c) => active(c) && c.type === 'weight' && !c.bind_visitors).map((c) => F(RULES_BY_ID.F11, camp(c), 'Flow rotation is By weight and Bind visitors is off. Returning visitors are re-split, which blurs the test.')),
  },
  {
    id: 'F12', severity: 'low', area: 'Split tests', title: 'Active flow with weight 0',
    fix: 'Pause the flow if it should get nothing; otherwise give it a weight.',
    where: 'Campaign → Flows → Weight', source: DOCS.flows,
    run: (s) => (s.campaigns || []).filter((c) => active(c) && c.type === 'weight').flatMap((c) => (s.streams[c.id] || []).filter((f) => active(f) && f.type === 'regular' && Number(f.weight) === 0)
      .map((f) => F(RULES_BY_ID.F12, flow(c, f), 'Weight is 0: only visitors already bound to it still reach it; new clicks do not.'))),
  },
  {
    id: 'F13', severity: 'low', area: 'Reporting', title: 'Campaign has no cost set',
    fix: 'Set the cost model, turn on automatic costs from the source, or upload costs with Update costs, so ROI and profit are real.',
    where: 'Campaign → Settings → Cost', source: DOCS.campaign,
    run: (s) => (s.campaigns || []).filter((c) => active(c) && !c.cost_auto && Number(c.cost_value || 0) === 0 && !['RevShare', 'CPA', 'CPS'].includes(c.cost_type)).map((c) => F(RULES_BY_ID.F13, camp(c), `Cost type ${c.cost_type || 'not set'} with value 0 and no automatic costs. ROI reports treat this traffic as free unless costs are uploaded.`)),
  },
  {
    id: 'F14', severity: 'medium', area: 'Sources', title: 'Campaign without a traffic source',
    fix: 'Attach the traffic source template so its parameters (zone, site, creative) land in sub IDs you can filter and report on.',
    where: 'Campaign → Settings → Traffic source', source: DOCS.campaign,
    run: (s) => (s.campaigns || []).filter((c) => active(c) && !c.traffic_source_id).map((c) => F(RULES_BY_ID.F14, camp(c), 'No traffic source is attached, so placements can\'t be filtered or reported per zone.')),
  },
  {
    id: 'F15', severity: 'medium', area: 'Filters', title: 'Filter not available on this tracker',
    fix: 'Re-install the custom filter file or remove the filter. Keitaro lists its filters at /admin_api/v1/stream_filters; this name is not there.',
    where: 'Flow → Filters', source: DOCS.api,
    run: (s) => {
      const known = new Set((s.stream_filters || []).map((x) => String(x.value || x.name || '').toLowerCase()).filter(Boolean));
      if (!known.size) return [];
      return (s.campaigns || []).filter(active).flatMap((c) => (s.streams[c.id] || []).filter(active).flatMap((f) => (f.filters || [])
        .filter((x) => !known.has(fname(x)))
        .map((x) => F(RULES_BY_ID.F15, flow(c, f), `Filter "${fname(x)}" is used here but the tracker doesn't list it.`))));
    },
  },
  {
    id: 'F16', severity: 'info', area: 'Filters', title: 'Proxy filter depends on the PX2 database',
    fix: 'Check Maintenance → Geo DBs for IP2Location PX2. Without it the Proxy filter only sees proxies that announce themselves in HTTP headers.',
    where: 'Maintenance → Geo DBs', source: DOCS.filters,
    run: (s) => {
      const uses = (s.campaigns || []).filter(active).flatMap((c) => (s.streams[c.id] || []).filter((f) => active(f) && (f.filters || []).some((x) => fname(x) === 'proxy')).map((f) => flow(c, f).name));
      return uses.length ? [F(RULES_BY_ID.F16, { type: 'tracker', id: null, name: 'Geo databases' }, `The Proxy filter is used in ${plural(uses.length, 'flow', 'flows')}: ${uses.slice(0, 4).join('; ')}${uses.length > 4 ? '…' : ''}.`)] : [];
    },
  },
  {
    id: 'F17', severity: 'info', area: 'Filters', title: 'ISP / connection filters depend on the geo database',
    fix: 'Confirm Keitaro Geo or IP2Location DB4 is active; the ISP filter needs one of them.',
    where: 'Maintenance → Geo DBs', source: DOCS.geodb,
    run: (s) => {
      const uses = (s.campaigns || []).filter(active).flatMap((c) => (s.streams[c.id] || []).filter((f) => active(f) && (f.filters || []).some((x) => ['isp', 'connection_type'].includes(fname(x)))).map((f) => flow(c, f).name));
      return uses.length ? [F(RULES_BY_ID.F17, { type: 'tracker', id: null, name: 'Geo databases' }, `ISP or connection-type filters are used in ${plural(uses.length, 'flow', 'flows')}.`)] : [];
    },
  },
  {
    id: 'F18', severity: 'medium', area: 'Offers', title: 'Flow points to a disabled or missing offer',
    fix: 'Replace the offer in the flow or re-enable it, so the flow\'s share of clicks goes somewhere useful.',
    where: 'Flow → Schema → Offers', source: DOCS.flows,
    run: (s) => {
      const offers = new Map((s.offers || []).map((o) => [Number(o.id), o]));
      return (s.campaigns || []).filter(active).flatMap((c) => (s.streams[c.id] || []).filter(active).flatMap((f) => offerIds(f)
        .filter((id) => !offers.has(id) || !active(offers.get(id)))
        .map((id) => F(RULES_BY_ID.F18, flow(c, f), offers.has(id) ? `Offer #${id} "${offers.get(id).name}" is ${offers.get(id).state}.` : `Offer #${id} does not exist (deleted or archived).`))));
    },
  },
  // ---------- offers and networks ----------
  {
    id: 'O01', severity: 'high', area: 'Conversions', title: 'Offer URL without {subid}',
    fix: 'Add the network\'s click parameter with {subid} (for example sub1={subid}) or attach the affiliate network template, which adds it for you.',
    where: 'Offers → offer → URL / Affiliate network', source: DOCS.networks,
    run: (s) => {
      const used = new Set((s.campaigns || []).filter(active).flatMap((c) => (s.streams[c.id] || []).filter(active).flatMap(offerIds)));
      return (s.offers || []).filter((o) => active(o) && used.has(Number(o.id)) && !o.affiliate_network_id && /^https?:/i.test(o.action_payload || '') && !/\{subid\}/i.test(o.action_payload || ''))
        .map((o) => F(RULES_BY_ID.O01, { type: 'offer', id: o.id, name: o.name }, 'The offer has no affiliate network and its URL doesn\'t pass {subid}, so the network can\'t send the click ID back and postbacks can\'t be matched.'));
    },
  },
  {
    id: 'O02', severity: 'high', area: 'Conversions', title: 'Affiliate network does not pass {subid}',
    fix: 'Set Offer parameters to the network\'s click field with {subid}, for example sub1={subid}. Keitaro calls subid the mandatory postback parameter.',
    where: 'Affiliate networks → network → Offer parameters', source: DOCS.networks,
    run: (s) => {
      const usedNetworks = new Set((s.offers || []).filter(active).map((o) => o.affiliate_network_id).filter(Boolean).map(Number));
      return (s.affiliate_networks || []).filter((n) => active(n) && usedNetworks.has(Number(n.id)) && !/\{subid\}/i.test(n.offer_param || ''))
        .map((n) => F(RULES_BY_ID.O02, { type: 'affiliate_network', id: n.id, name: n.name }, `Offer parameters are "${n.offer_param || '(empty)'}", with no {subid}. Every offer on this network sends clicks without the click ID.`));
    },
  },
  {
    id: 'O03', severity: 'medium', area: 'Conversions', title: 'CPA offer records zero revenue',
    fix: 'Set a fixed payout, or switch Payout to "from postback" so the network\'s payout value is used.',
    where: 'Offers → offer → Payout', source: DOCS.offers,
    run: (s) => (s.offers || []).filter((o) => active(o) && (o.payout_type || 'CPA') === 'CPA' && !o.payout_auto && Number(o.payout_value || 0) === 0)
      .map((o) => F(RULES_BY_ID.O03, { type: 'offer', id: o.id, name: o.name }, 'Fixed payout 0 and payout from postback off: every conversion is recorded with $0 revenue.')),
  },
  {
    id: 'O04', severity: 'low', area: 'Offers', title: 'Offer URL uses http://',
    fix: 'Use the https:// version of the link if the network supports it.',
    where: 'Offers → offer → URL', source: DOCS.offers,
    run: (s) => (s.offers || []).filter((o) => active(o) && /^http:\/\//i.test(o.action_payload || '')).map((o) => F(RULES_BY_ID.O04, { type: 'offer', id: o.id, name: o.name }, 'Plain-HTTP offer link: some browsers warn on the redirect and the referrer can leak.')),
  },
  {
    id: 'O05', severity: 'info', area: 'Housekeeping', title: 'Active offers not used in any flow',
    fix: 'Archive offers you no longer run, so reports and flow editors stay readable.',
    where: 'Offers', source: DOCS.offers,
    run: (s) => {
      const used = new Set((s.campaigns || []).flatMap((c) => (s.streams[c.id] || []).flatMap(offerIds)));
      const unused = (s.offers || []).filter((o) => active(o) && !used.has(Number(o.id)));
      return unused.length ? [F(RULES_BY_ID.O05, { type: 'offers', id: null, name: plural(unused.length, 'unused offer', 'unused offers') }, unused.map((o) => `#${o.id} ${o.name}`).join('; '))] : [];
    },
  },
  {
    id: 'O06', severity: 'low', area: 'Housekeeping', title: 'Duplicate offers',
    fix: 'Merge duplicates so conversions and payouts aren\'t split across two records.',
    where: 'Offers', source: DOCS.offers,
    run: (s) => {
      const seen = new Map();
      for (const o of (s.offers || []).filter(active)) {
        const k = String(o.action_payload || '').trim().toLowerCase().replace(/\/+$/, '');
        if (!k) continue;
        (seen.get(k) || seen.set(k, []).get(k)).push(o);
      }
      return [...seen.values()].filter((a) => a.length > 1).map((a) => F(RULES_BY_ID.O06, { type: 'offers', id: a.map((o) => o.id).join(','), name: a.map((o) => o.name).join(' / ') }, `${a.length} offers share the same URL.`));
    },
  },
  // ---------- domains ----------
  {
    id: 'D01', severity: 'high', area: 'Domains', title: 'Tracking domain without SSL',
    fix: 'Point DNS to the tracker and let Keitaro issue the certificate (Maintenance → Logs → SSL shows errors).',
    where: 'Domains → domain → SSL', source: DOCS.domains,
    run: (s) => (s.domains || []).filter((d) => active(d) && d.is_ssl === false).map((d) => F(RULES_BY_ID.D01, { type: 'domain', id: d.id, name: d.name }, 'No SSL certificate: links are served over plain HTTP, which many sources and browsers reject or warn about.')),
  },
  {
    id: 'D02', severity: 'medium', area: 'Domains', title: 'HTTPS-only is off',
    fix: 'Turn on HTTPS-only so http:// links redirect to https://.',
    where: 'Domains → domain → HTTPS-only', source: DOCS.domains,
    run: (s) => (s.domains || []).filter((d) => active(d) && d.is_ssl === true && d.ssl_redirect === false).map((d) => F(RULES_BY_ID.D02, { type: 'domain', id: d.id, name: d.name }, 'The certificate exists but http:// requests are not redirected to https://.')),
  },
  {
    id: 'D03', severity: 'medium', area: 'Security', title: 'Admin panel open on a tracking domain',
    fix: 'Turn Admin Dashboard off on tracking domains and keep one separate admin domain (with an IP allowlist).',
    where: 'Domains → domain → Admin Dashboard', source: DOCS.domains,
    run: (s) => (s.domains || []).filter((d) => active(d) && d.admin_dashboard === true && (Number(d.campaigns_count || 0) > 0 || d.default_campaign_id)).map((d) => F(RULES_BY_ID.D03, { type: 'domain', id: d.id, name: d.name }, `${d.name}/admin opens the login page on a domain that appears in ad links.`)),
  },
  {
    id: 'D04', severity: 'low', area: 'Domains', title: 'Search crawlers allowed on a tracking domain',
    fix: 'Set Crawlers to Disallowed so robots.txt blocks indexing of tracking URLs.',
    where: 'Domains → domain → Crawlers', source: DOCS.domains,
    run: (s) => (s.domains || []).filter((d) => active(d) && d.allow_indexing === true).map((d) => F(RULES_BY_ID.D04, { type: 'domain', id: d.id, name: d.name }, 'robots.txt allows crawling, so tracking links can end up in search results.')),
  },
  {
    id: 'D05', severity: 'medium', area: 'Domains', title: 'Domain status is not OK',
    fix: 'Check that the domain has a single A record pointing to the tracker, then run the domain check again.',
    where: 'Domains → domain → Check', source: DOCS.domains,
    run: (s) => (s.domains || []).filter((d) => active(d) && d.network_status && !['active', 'ok', 'success', 'valid'].includes(String(d.network_status).toLowerCase())).map((d) => F(RULES_BY_ID.D05, { type: 'domain', id: d.id, name: d.name }, `Network status is "${d.network_status}".`)),
  },
  {
    id: 'D06', severity: 'medium', area: 'Domains', title: 'Index page campaign is disabled or missing',
    fix: 'Pick an active campaign for the index page or clear the setting.',
    where: 'Domains → domain → Index page', source: DOCS.domains,
    run: (s) => {
      const camps = new Map((s.campaigns || []).map((c) => [Number(c.id), c]));
      return (s.domains || []).filter((d) => active(d) && d.default_campaign_id && (!camps.has(Number(d.default_campaign_id)) || !active(camps.get(Number(d.default_campaign_id)))))
        .map((d) => F(RULES_BY_ID.D06, { type: 'domain', id: d.id, name: d.name }, `The bare domain opens campaign #${d.default_campaign_id}, which is ${camps.has(Number(d.default_campaign_id)) ? camps.get(Number(d.default_campaign_id)).state : 'missing'}.`));
    },
  },
  {
    id: 'D07', severity: 'low', area: 'Domains', title: 'Intercept 404 has no effect',
    fix: 'Intercept 404 only works with an index page campaign. Set one or turn the option off.',
    where: 'Domains → domain → Intercept 404', source: DOCS.domains,
    run: (s) => (s.domains || []).filter((d) => active(d) && d.catch_not_found === true && !d.default_campaign_id).map((d) => F(RULES_BY_ID.D07, { type: 'domain', id: d.id, name: d.name }, 'Intercept 404 is on but no index page campaign is set.')),
  },
  {
    id: 'D08', severity: 'info', area: 'Housekeeping', title: 'Parked domain with no campaigns',
    fix: 'Keep spare domains, but check their status before the day you need them.',
    where: 'Domains', source: DOCS.domains,
    run: (s) => {
      const idle = (s.domains || []).filter((d) => active(d) && Number(d.campaigns_count || 0) === 0 && !d.default_campaign_id && !d.admin_dashboard);
      return idle.length ? [F(RULES_BY_ID.D08, { type: 'domains', id: null, name: plural(idle.length, 'idle domain', 'idle domains') }, idle.map((d) => d.name).join(', '))] : [];
    },
  },
  // ---------- bot list ----------
  {
    id: 'B01', severity: 'info', area: 'Bot list', title: 'Custom bot list is empty',
    fix: 'Add the data-center ranges and user-agent tokens found in your own click log (the analyzer outputs them in the right format).',
    where: 'Settings → Bot lists', source: DOCS.botlists,
    run: (s, ctx) => (ctx.botLines.length === 0 && s.botlist !== null && s.botlist !== undefined ? [F(RULES_BY_ID.B01, { type: 'tracker', id: null, name: 'Bot list' }, 'Only the built-in lists are in use.')] : []),
  },
  {
    id: 'B02', severity: 'low', area: 'Bot list', title: 'Bot list has invalid, duplicate or private entries',
    fix: 'Remove these lines; they do nothing or hide real mistakes.',
    where: 'Settings → Bot lists → Remove', source: DOCS.botlists,
    run: (s, ctx) => {
      const bad = []; const seen = new Set();
      for (const line of ctx.botLines) {
        const c = parseCIDR(line);
        if (!c) { bad.push(`"${line}" is not an IP or CIDR`); continue; }
        if (seen.has(line)) bad.push(`"${line}" is listed twice`);
        seen.add(line);
        const ip = parseIP(line.split('/')[0]);
        if (ip && c.v === 4 && ((c.start >= 0x0a000000 && c.end <= 0x0affffff) || (c.start >= 0xc0a80000 && c.end <= 0xc0a8ffff) || (c.start >= 0xac100000 && c.end <= 0xac1fffff))) bad.push(`"${line}" is a private range and never appears in public traffic`);
      }
      return bad.length ? [F(RULES_BY_ID.B02, { type: 'tracker', id: null, name: 'Bot list' }, bad.join('; '))] : [];
    },
  },
  {
    id: 'B03', severity: 'medium', area: 'Bot list', title: 'Bot list blocks consumer ISP addresses',
    fix: 'Replace broad entries with the specific data-center prefixes. Ranges this wide also catch real visitors.',
    where: 'Settings → Bot lists', source: DOCS.botlists,
    run: (s, ctx) => {
      const out = [];
      for (const line of ctx.botLines) {
        const c = parseCIDR(line);
        if (!c || c.v !== 4) continue;
        const width = c.end - c.start + 1;
        let consumer = null;
        if (ctx.netdb) {
          // sample the range to see which networks it covers
          for (let k = 0; k < 16 && !consumer; k++) {
            const n = ctx.netdb.lookup({ v: 4, n: c.start + Math.floor((width - 1) * (k / 15)) });
            if (n && n.consumer) consumer = `AS${n.asn} ${n.name}`;
          }
        }
        if (consumer) out.push(`${line} covers ${consumer}`);
        else if (c.len < 16 && !(c.start >= 0x0a000000 && c.end <= 0x0affffff)) out.push(`${line} is wider than a /16 (${width.toLocaleString('en-US')} addresses)`);
      }
      return out.length ? [F(RULES_BY_ID.B03, { type: 'tracker', id: null, name: 'Bot list' }, out.join('; '))] : [];
    },
  },
  // ---------- reports (optional) ----------
  {
    id: 'R01', severity: 'medium', area: 'Traffic quality', title: 'Source with a high bot share',
    fix: 'Pull the click log for this source, find the placements behind the bots, block them at the source and ask for a refund.',
    where: 'Reports → group by Traffic source → Bots, Bot share', source: DOCS.filters,
    run: (s) => (s.reports && s.reports.bySource || []).filter((r) => Number(r.clicks) >= 500).map((r) => ({ r, share: Number(r.bots) / Number(r.clicks) }))
      .filter((x) => x.share >= 0.2).map(({ r, share }) => F(RULES_BY_ID.R01, { type: 'traffic_source', id: null, name: String(r.ts || r.traffic_source || r.name) }, `${Math.round(share * 100)}% of ${Number(r.clicks).toLocaleString('en-US')} clicks were marked as bots by Keitaro in ${s.reports.range.from} – ${s.reports.range.to}.`)),
  },
  {
    id: 'R02', severity: 'medium', area: 'Conversions', title: 'Busy campaign with zero conversions',
    fix: 'Check Maintenance → Logs → Postbacks for this campaign\'s offers; zero conversions on this much traffic usually means postbacks aren\'t arriving or aren\'t matching.',
    where: 'Maintenance → Logs → Postbacks', source: DOCS.postback,
    run: (s) => (s.reports && s.reports.byCampaign || []).filter((r) => Number(r.clicks) >= 1000 && Number(r.conversions || 0) === 0)
      .map((r) => F(RULES_BY_ID.R02, { type: 'campaign', id: null, name: String(r.campaign || r.name) }, `${Number(r.clicks).toLocaleString('en-US')} clicks and 0 conversions in ${s.reports.range.from} – ${s.reports.range.to}.`)),
  },
];

export const RULES_BY_ID = Object.fromEntries(RULES.map((r) => [r.id, r]));

export function botLinesOf(botlist) {
  if (botlist === null || botlist === undefined) return [];
  const raw = Array.isArray(botlist) ? botlist.map((x) => (typeof x === 'object' ? x.value ?? x.ip ?? '' : x)).join('\n') : typeof botlist === 'object' ? botlist.value ?? '' : String(botlist);
  return String(raw).split(/[\n;,]+/).map((x) => x.trim()).filter(Boolean);
}

export function runRules(snapshot, { netdb = null, only = null, skip = [] } = {}) {
  const s = { streams: {}, ...snapshot };
  const ctx = { netdb, botLines: botLinesOf(snapshot.botlist) };
  const findings = [];
  for (const rule of RULES) {
    if (only && !only.includes(rule.id)) continue;
    if (skip.includes(rule.id)) continue;
    try { findings.push(...rule.run(s, ctx)); } catch (e) { findings.push({ rule: rule.id, severity: 'info', area: 'Audit', title: `Rule ${rule.id} could not run`, entity: { type: 'tracker' }, detail: e.message, fix: '', where: '', source: '' }); }
  }
  for (const [ep, st] of Object.entries((snapshot.meta && snapshot.meta.endpoints) || {})) {
    if (!st.ok) findings.push({ rule: 'API', severity: 'info', area: 'Audit', title: `Couldn't read ${ep}`, entity: { type: 'endpoint', id: ep, name: ep }, detail: `HTTP ${st.status}${st.error ? ': ' + st.error : ''}. Checks that need it were skipped.`, fix: 'Give the API key a role that can read this section, or run the check by hand.', where: 'Maintenance → Users → Admin API keys', source: DOCS.api });
  }
  findings.sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity] || a.rule.localeCompare(b.rule));
  return findings;
}

export function scoreFindings(findings) {
  const by = { high: 0, medium: 0, low: 0, info: 0 };
  for (const f of findings) by[f.severity]++;
  return by;
}

export { v4ToString };
