// Redacts a snapshot before it leaves the client's machine: removes campaign tokens and
// postback keys, and blanks query values in URLs (macros like {subid} are kept, because the
// audit checks for them).
function redactUrl(u) {
  if (typeof u !== 'string' || !u) return u;
  try {
    const hasScheme = /^https?:\/\//i.test(u);
    const url = new URL(hasScheme ? u : 'https://x.invalid/' + u.replace(/^\/+/, ''));
    const keep = new URLSearchParams();
    for (const [k, v] of url.searchParams) keep.append(k, /\{[^}]+\}/.test(v) ? v : 'x');
    const q = [...keep].map(([k, v]) => `${encodeURIComponent(k)}=${/\{[^}]+\}/.test(v) ? v : encodeURIComponent(v)}`).join('&');
    if (!hasScheme) return url.pathname.slice(1) + (q ? '?' + q : '');
    return `${url.protocol}//${url.host}${url.pathname}${q ? '?' + q : ''}`;
  } catch {
    return u.replace(/=([^&{}]+)(?=&|$)/g, '=x');
  }
}

export function redactSnapshot(snap) {
  const s = JSON.parse(JSON.stringify(snap));
  for (const c of s.campaigns || []) {
    if ('token' in c) c.token = '[redacted]';
    for (const p of c.postbacks || []) p.url = redactUrl(p.url);
  }
  for (const n of s.affiliate_networks || []) {
    // the tracker's own postback URL carries its secret key in the path
    if (n.postback_url) n.postback_url = String(n.postback_url).replace(/^(https?:\/\/[^/]+\/)[^/?]+/i, '$1[key]');
    if (n.pull_api_options) n.pull_api_options = '[redacted]';
  }
  for (const t of s.traffic_sources || []) if (t.postback_url) t.postback_url = redactUrl(t.postback_url);
  for (const o of s.offers || []) if (o.action_payload) o.action_payload = redactUrl(o.action_payload);
  for (const l of s.landing_pages || []) { if (l.action_payload) l.action_payload = redactUrl(l.action_payload); if (l.url) l.url = redactUrl(l.url); }
  for (const arr of Object.values(s.streams || {})) for (const f of arr || []) if (f.action_payload) f.action_payload = redactUrl(f.action_payload);
  s.meta = { ...(s.meta || {}), redacted: true };
  return s;
}
