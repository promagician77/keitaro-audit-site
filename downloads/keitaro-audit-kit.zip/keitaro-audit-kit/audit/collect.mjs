// Pulls a read-only snapshot of a Keitaro tracker through the Admin API.
export const ENDPOINTS = ['campaigns', 'offers', 'landing_pages', 'affiliate_networks', 'traffic_sources', 'domains', 'botlist', 'stream_filters'];

const asArray = (d) => (Array.isArray(d) ? d : d && Array.isArray(d.data) ? d.data : d && Array.isArray(d.rows) ? d.rows : null);

export async function collectSnapshot(client, opts = {}) {
  const snap = { meta: { collectedAt: new Date().toISOString(), endpoints: {}, tool: 'keitaro-audit 1.0' } };
  for (const ep of ENDPOINTS) {
    const r = await client.get(ep);
    const arr = asArray(r.data);
    snap.meta.endpoints[ep] = { ok: r.ok, status: r.status, count: arr ? arr.length : r.data ? 1 : 0, error: r.error };
    if (r.status === 401 || r.status === 403) throw new Error(`The tracker refused the API key (HTTP ${r.status}). Check the key under Maintenance → Users → Admin API keys.`);
    snap[ep] = r.ok ? (arr ?? r.data) : null;
  }
  snap.streams = {};
  for (const c of snap.campaigns || []) {
    if (c.state === 'deleted') continue;
    const r = await client.get(`campaigns/${c.id}/streams`);
    snap.streams[c.id] = r.ok ? asArray(r.data) || [] : null;
    if (!r.ok) snap.meta.endpoints[`campaigns/${c.id}/streams`] = { ok: false, status: r.status, error: r.error };
  }
  if (opts.withReports) {
    const days = opts.days || 7;
    const to = new Date(); const from = new Date(Date.now() - days * 86400000);
    const range = { from: from.toISOString().slice(0, 10), to: to.toISOString().slice(0, 10), timezone: opts.timezone || 'UTC' };
    const metrics = ['clicks', 'bots', 'bot_share', 'proxies', 'empty_referrers', 'conversions', 'leads', 'sales'];
    snap.reports = { range };
    for (const [name, grouping] of [['bySource', ['ts']], ['byCampaign', ['campaign']]]) {
      const r = await client.post('report/build', { range, grouping, metrics, sort: [{ name: 'clicks', order: 'DESC' }] });
      snap.reports[name] = r.ok ? (asArray(r.data) || (r.data && r.data.rows) || []) : null;
      snap.meta.endpoints[`report/build:${grouping[0]}`] = { ok: r.ok, status: r.status, error: r.error };
    }
  }
  return snap;
}
