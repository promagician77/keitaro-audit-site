#!/usr/bin/env node
// Read-only Keitaro audit.
//
//   Live tracker (only GET requests; add --with-reports to also POST read-only report queries):
//     KEITARO_API_KEY=... node audit/keitaro-audit.mjs --url https://tracker.example.com --out audit-out
//
//   Make a redacted snapshot to share instead of an API key:
//     KEITARO_API_KEY=... node audit/keitaro-audit.mjs --url https://tracker.example.com --snapshot-only --out audit-out
//
//   Audit a snapshot file offline:
//     node audit/keitaro-audit.mjs --from-snapshot audit-out/snapshot.redacted.json --out audit-out
import fs from 'node:fs';
import path from 'node:path';
import { createClient } from './client.mjs';
import { collectSnapshot } from './collect.mjs';
import { redactSnapshot } from './redact.mjs';
import { runRules, scoreFindings } from './rules.mjs';
import { renderMarkdown, renderHTML } from './report.mjs';

function args(argv) {
  const a = { out: 'audit-out', keyEnv: 'KEITARO_API_KEY', days: 7 };
  for (let i = 2; i < argv.length; i++) {
    const k = argv[i];
    const next = () => argv[++i];
    if (k === '--url') a.url = next();
    else if (k === '--key-env') a.keyEnv = next();
    else if (k === '--out') a.out = next();
    else if (k === '--from-snapshot') a.fromSnapshot = next();
    else if (k === '--snapshot-only') a.snapshotOnly = true;
    else if (k === '--with-reports') a.withReports = true;
    else if (k === '--days') a.days = Number(next());
    else if (k === '--no-netdb') a.noNetdb = true;
    else if (k === '-h' || k === '--help') a.help = true;
    else throw new Error(`Unknown option ${k}`);
  }
  return a;
}

export async function main(argv = process.argv, env = process.env) {
  const a = args(argv);
  if (a.help || (!a.url && !a.fromSnapshot)) {
    console.log('Usage: node audit/keitaro-audit.mjs --url https://tracker --out dir [--with-reports] [--snapshot-only]\n       node audit/keitaro-audit.mjs --from-snapshot file.json --out dir\nThe API key is read from $KEITARO_API_KEY (or --key-env NAME). Only read requests are sent.');
    return 0;
  }
  fs.mkdirSync(a.out, { recursive: true });
  let snapshot;
  let calls = [];
  if (a.fromSnapshot) {
    snapshot = JSON.parse(fs.readFileSync(a.fromSnapshot, 'utf8'));
  } else {
    const client = createClient({ baseUrl: a.url, apiKey: env[a.keyEnv], allowPost: a.withReports ? ['report/build'] : [] });
    snapshot = await collectSnapshot(client, { withReports: a.withReports, days: a.days });
    calls = client.calls;
    fs.writeFileSync(path.join(a.out, 'snapshot.redacted.json'), JSON.stringify(redactSnapshot(snapshot), null, 2));
    fs.writeFileSync(path.join(a.out, 'requests.log'), calls.map((c) => `${c.method} ${c.path}`).join('\n') + '\n');
    if (a.snapshotOnly) {
      console.log(`Saved ${path.join(a.out, 'snapshot.redacted.json')} (${calls.length} read requests). Tokens and postback keys are removed.`);
      return 0;
    }
  }
  let netdb = null;
  if (!a.noNetdb) {
    try { netdb = await (await import('../engine/netdb.mjs')).loadNetDBNode(); } catch { netdb = null; }
  }
  const findings = runRules(snapshot, { netdb });
  fs.writeFileSync(path.join(a.out, 'findings.json'), JSON.stringify({ meta: snapshot.meta, score: scoreFindings(findings), findings }, null, 2));
  fs.writeFileSync(path.join(a.out, 'audit.md'), renderMarkdown(findings, snapshot.meta));
  fs.writeFileSync(path.join(a.out, 'audit.html'), renderHTML(findings, snapshot.meta));
  const s = scoreFindings(findings);
  console.log(`${findings.length} findings (${s.high} high, ${s.medium} medium, ${s.low} low, ${s.info} info) → ${path.join(a.out, 'audit.html')}`);
  return 0;
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().then((code) => process.exit(code), (e) => { console.error('Audit stopped: ' + e.message); process.exit(1); });
}
