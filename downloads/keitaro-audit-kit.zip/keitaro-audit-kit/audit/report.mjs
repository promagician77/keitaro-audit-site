// Renders audit findings as Markdown (for a ticket or chat) and as a standalone HTML page.
import { scoreFindings } from './rules.mjs';

const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const LABEL = { high: 'High', medium: 'Medium', low: 'Low', info: 'Info' };

export const MANUAL_CHECKS = [
  ['Geo databases', 'Maintenance → Geo DBs: which database answers ISP lookups (Keitaro Geo or IP2Location DB4), and is IP2Location PX2 loaded for the Proxy filter?'],
  ['Bot list switches', 'Settings → Bot lists: additional User-Agent list, Bot IP list, empty user agent as bot, Spambot list, and skipping bot traffic in cost updates.'],
  ['Real visitor IP', 'If tracking domains sit behind Cloudflare or another proxy, check the click log for proxy addresses. The log analyzer reports the share of clicks from Cloudflare edge IPs.'],
  ['Server health', 'Maintenance → Status: CPU stolen, disk space, and any ClickHouse upgrade notice. kctl repair fixes common server issues.'],
  ['Postback log', 'Maintenance → Logs → Postbacks: "Incorrect subid" and "Click for subid not found" errors point at the network or offer that isn\'t passing {subid}.'],
  ['Admin access', 'Admin panel on one domain only, admin IP allowlist set, one API key per person or tool with the narrowest role.'],
];

export function renderMarkdown(findings, meta = {}) {
  const s = scoreFindings(findings);
  const lines = [`# Keitaro audit`, '', `${findings.length} findings: ${s.high} high, ${s.medium} medium, ${s.low} low, ${s.info} info.${meta.collectedAt ? ` Snapshot taken ${meta.collectedAt}.` : ''}`, ''];
  for (const sev of ['high', 'medium', 'low', 'info']) {
    const group = findings.filter((f) => f.severity === sev);
    if (!group.length) continue;
    lines.push(`## ${LABEL[sev]}`, '');
    for (const f of group) {
      lines.push(`### ${f.rule} · ${f.title} — ${f.entity.name ?? ''}`.trim(), '', f.detail, '', `**Fix:** ${f.fix}`, '', `Where: ${f.where}${f.source ? ` · [docs](${f.source})` : ''}`, '');
    }
  }
  lines.push('## Checked by hand (not visible through the API)', '');
  for (const [k, v] of MANUAL_CHECKS) lines.push(`- **${k}.** ${v}`);
  return lines.join('\n') + '\n';
}

export function renderHTML(findings, meta = {}) {
  const s = scoreFindings(findings);
  const items = findings.map((f) => `<article class="f ${f.severity}"><header><span class="sev">${LABEL[f.severity]}</span><span class="id">${esc(f.rule)}</span><h3>${esc(f.title)}</h3><p class="ent">${esc(f.entity.name ?? '')}</p></header><p>${esc(f.detail)}</p><p class="fix"><b>Fix.</b> ${esc(f.fix)}</p><p class="where">${esc(f.where)}${f.source ? ` · <a href="${esc(f.source)}">Keitaro docs</a>` : ''}</p></article>`).join('\n');
  return `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Keitaro audit</title>
<style>body{font:15px/1.55 system-ui,sans-serif;margin:0;background:#f4f6f5;color:#1d2321}main{max-width:860px;margin:0 auto;padding:32px 20px}h1{font-size:28px;margin:0 0 4px}.sum{color:#4a5552;margin:0 0 24px}
.f{background:#fff;border:1px solid #d9dfdc;border-left:6px solid #9aa5a1;border-radius:6px;padding:14px 18px;margin:0 0 12px}.f.high{border-left-color:#c0392b}.f.medium{border-left-color:#d68910}.f.low{border-left-color:#2e86c1}
.f header{display:flex;flex-wrap:wrap;gap:8px;align-items:baseline}.f h3{margin:0;font-size:16px}.sev{font-size:12px;font-weight:700}.id{font:12px ui-monospace,monospace;color:#5d6965}.ent{flex-basis:100%;margin:2px 0 0;color:#4a5552}.fix{background:#eef3f0;padding:8px 10px;border-radius:4px}.where{font-size:13px;color:#5d6965}
li{margin:0 0 6px}</style></head><body><main><h1>Keitaro audit</h1><p class="sum">${findings.length} findings: ${s.high} high, ${s.medium} medium, ${s.low} low, ${s.info} info.${meta.collectedAt ? ` Snapshot ${esc(meta.collectedAt)}.` : ''}${meta.redacted ? ' Redacted snapshot.' : ''}</p>
${items}
<h2>Checked by hand</h2><ul>${MANUAL_CHECKS.map(([k, v]) => `<li><b>${esc(k)}.</b> ${esc(v)}</li>`).join('')}</ul></main></body></html>`;
}
