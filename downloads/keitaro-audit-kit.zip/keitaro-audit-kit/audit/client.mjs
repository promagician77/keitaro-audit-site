// Read-only Keitaro Admin API client. Every request goes through one guard:
// GET is allowed; POST only to report/build and clicks/log (read queries that Keitaro
// exposes as POST), and only when the caller opts in. PUT and DELETE are never sent.
export const READ_POSTS = ['report/build', 'clicks/log'];

export class ReadOnlyError extends Error {}

export function createClient({ baseUrl, apiKey, fetchImpl = globalThis.fetch, allowPost = [], timeoutMs = 30000 }) {
  if (!baseUrl) throw new Error('Tracker URL is required (e.g. https://tracker.example.com)');
  if (!apiKey) throw new Error('Admin API key is required (Maintenance → Users → Admin API keys)');
  const root = baseUrl.replace(/\/+$/, '').replace(/\/admin_api\/v1$/, '') + '/admin_api/v1/';
  const calls = [];
  async function request(method, path, body) {
    const p = path.replace(/^\/+/, '');
    const postOk = method === 'POST' && READ_POSTS.includes(p) && allowPost.includes(p);
    if (method !== 'GET' && !postOk) throw new ReadOnlyError(`Blocked ${method} ${p}: this audit only reads`);
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), timeoutMs);
    calls.push({ method, path: p });
    try {
      const res = await fetchImpl(root + p, {
        method,
        headers: { 'Api-Key': apiKey, Accept: 'application/json', ...(body ? { 'Content-Type': 'application/json' } : {}) },
        body: body ? JSON.stringify(body) : undefined,
        signal: ctrl.signal,
      });
      const text = await res.text();
      let data = null;
      try { data = text ? JSON.parse(text) : null; } catch { data = null; }
      return { ok: res.ok, status: res.status, data, error: res.ok ? null : (data && (data.error || data.message)) || text.slice(0, 200) };
    } catch (e) {
      return { ok: false, status: 0, data: null, error: e.name === 'AbortError' ? `timed out after ${timeoutMs} ms` : e.message };
    } finally {
      clearTimeout(timer);
    }
  }
  return {
    calls,
    get: (p) => request('GET', p),
    post: (p, body) => request('POST', p, body),
  };
}
